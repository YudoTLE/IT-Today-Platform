import { db } from '../config/database.config.js'
import { milisecondsToDate, formatId, dateToMiliseconds, rawMilisecondsToDate } from '../utils/admin.util.js'

export const getEvents = async () => {
    const query = await db('SELECT * FROM events ORDER BY id')
    const datas = query.rows
    datas.forEach(data => {
        data.registration_open_date = milisecondsToDate(data.registration_open_date)
        data.registration_close_date = milisecondsToDate(data.registration_close_date)
    })

    return datas
}

export const addEvent = async (datas) => {
    const { name, category, description } = datas
    let { capacity, registration_open_date, registration_close_date } = datas

    capacity = parseInt(capacity)   
    registration_open_date = dateToMiliseconds(registration_open_date)
    registration_close_date = dateToMiliseconds(registration_close_date)
    const id = formatId(name)
    const id_category = formatId(category)
    const status_availibility = false

    await db(
        `INSERT INTO events 
        (
            id, 
            name, 
            id_category, 
            category, 
            capacity,
            registration_open_date, 
            registration_close_date, 
            status_availibility,
            description
        ) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`, 
        [
            id, 
            name, 
            id_category,
            category,
            capacity,
            registration_open_date, 
            registration_close_date, 
            status_availibility,
            description
        ]
    )
}

export const deleteEvent = async (id) => {
    await db(
        'DELETE FROM events WHERE id = $1', 
        [id]
    )
}

export const updateEvent = async (id, datas) => {
    const { name, category, description } = datas
    let { capacity, registration_open_date, registration_close_date } = datas

    capacity = parseInt(capacity)
    const id_category = formatId(category)
    registration_open_date = dateToMiliseconds(registration_open_date)
    registration_close_date = dateToMiliseconds(registration_close_date)

    await db(
        `UPDATE events
            SET
                name = $1,
                category = $2,
                id_category = $3,
                capacity = $4,
                registration_open_date = $5,
                registration_close_date = $6,
                description = $7
            WHERE 
                id = $8`,
        [name, category, id_category, capacity, registration_open_date, registration_close_date, description, id]
    )
}

export const getEventById = async (id) => {
    const query = await db(
        'SELECT * FROM events WHERE id = $1', 
        [id]
    )
    const data = query.rows[0]

    data.registration_open_date = rawMilisecondsToDate(data.registration_open_date)
    data.registration_close_date = rawMilisecondsToDate(data.registration_close_date)

    return data
}

export const getCompetitions = async () => {
    const query = await db('SELECT * FROM competitions ORDER BY id')
    const datas = query.rows
    datas.forEach(data => {
        data.registration_open_date = milisecondsToDate(data.registration_open_date)
        data.registration_close_date = milisecondsToDate(data.registration_close_date)
    })

    return datas
}

export const getCompetitionById = async (id) => {
    const query = await db(
        'SELECT * FROM competitions WHERE id = $1', 
        [id]
    )
    const data = query.rows[0]

    data.registration_open_date = rawMilisecondsToDate(data.registration_open_date)
    data.registration_close_date = rawMilisecondsToDate(data.registration_close_date)

    return data
}

export const addCompetition = async (datas) => {
    const { name, rulebook_link } = datas
    let { registration_open_date, registration_close_date } = datas

    registration_open_date = dateToMiliseconds(registration_open_date)
    registration_close_date = dateToMiliseconds(registration_close_date)
    const id = formatId(name)
    const status_availibility = false

    await db(
        `INSERT INTO competitions 
        (
            id, 
            name, 
            registration_open_date, 
            registration_close_date, 
            rulebook_link,
            status_availibility
        ) 
        VALUES ($1, $2, $3, $4, $5, $6)`, 
        [
            id, 
            name, 
            registration_open_date, 
            registration_close_date, 
            rulebook_link, 
            status_availibility
        ]
    )
}

export const updateCompetition = async (id, datas) => {
    const { name, rulebook_link } = datas
    let { registration_open_date, registration_close_date } = datas

    registration_open_date = dateToMiliseconds(registration_open_date)
    registration_close_date = dateToMiliseconds(registration_close_date)

    await db(
        `UPDATE competitions
            SET
                name = $1,
                registration_open_date = $2,
                registration_close_date = $3,
                rulebook_link = $4
            WHERE 
                id = $5`, 
        [name, registration_open_date, registration_close_date, rulebook_link, id]
    )
}

export const deleteCompetition = async (id) => {
    await db(
        'DELETE FROM competitions WHERE id = $1', 
        [id]
    )
}

export const updateStatusCompetition = async (competitionId, statusAvailibility) => {
    statusAvailibility = (statusAvailibility === 'false') ? true : false //reverse status

    await db(
        `UPDATE competitions 
            SET
                status_availibility = $1 
            WHERE 
                id = $2`, 
        [statusAvailibility, competitionId]
    )
}

export const updateStatusEvent = async (competitionId, statusAvailibility) => {
    statusAvailibility = (statusAvailibility === 'false') ? true : false //reverse status

    await db(
        `UPDATE events 
            SET
                status_availibility = $1 
            WHERE 
                id = $2`, 
        [statusAvailibility, competitionId]
    )
}