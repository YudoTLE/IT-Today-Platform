import { db } from '../config/database.config.js'
import { rawMilisecondsToDate } from '../utils/user.util.js'

export const queryTest = async () => {
    const query = await db('select * from users')
    const result = query.rows
    return result
}

export const login = async (username, password) => {

    //Belum bang

}

export const getCompetitionById = async (id) => {
    try {
        const query = await db(
            'SELECT * FROM competitions WHERE id = $1', 
            [id]
        )
        const data = query.rows[0]

        data.registration_open_date = rawMilisecondsToDate(data.registration_open_date)
        data.registration_close_date = rawMilisecondsToDate(data.registration_close_date)
        return data
    }

    catch(err){
        console.log(err)
        return null
    }
}