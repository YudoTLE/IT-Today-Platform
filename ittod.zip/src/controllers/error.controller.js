export const get404 = (req, res) => {
    return (
        res.render(`pages/client/404`, {
            title: `404 Not Found`,
            layout: "components/client/layout",
            nav_id: 1
        })
    )
}