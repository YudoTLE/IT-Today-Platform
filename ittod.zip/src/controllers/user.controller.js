import { 
    queryTest,
} from '../services/user.service.js'

import { nanoid } from 'nanoid'

export const test = async (req, res) => {
    res.send(nanoid())
    //const datas = await queryTest()
    //return res.send(datas)
}

export const homepage = (req, res) => {
    return (
        res.render("pages/client/main", {
            title: "IT Today",
            layout: "components/client/layout",
            nav_id: 0
        })
    )
}

export const dashboard = (req, res) => {
    return (
        res.render("pages/client/dashboard", {
            title: "Dashboard",
            layout: "components/client/layout",
            nav_id: 1
        })
    )
}

export const login_view = (req, res) => {
    return (
        res.render("pages/client/login", {
            title: "Login",
            layout: "components/client/layout",
            nav_id: 1
        })
    )
}

export const login_submit = (req, res) => {
    return res.send(req.body)
}

export const competition_view = (req, res) => {
    const { competitionId } = req.params
    return res.send(`Competition ${competitionId}`)
}

export const competitionForm_view = (req, res) => {
    const { competitionId } = req.params
    return (
        res.render(`pages/client/registerTeam`, {
            title: `Register Competition ${competitionId}`,
            layout: "components/client/layout",
            nav_id: 1,
            data: competitionId
        })
    )
}

export const competitionForm_submit = (req, res) => {
    const comeptitionId = req.params
    const { leader_name, leader_student_id_card, leader_letter_of_active_student_status } = req.body
    return res.send(req.body)
}