import express from 'express'

import { uploadPersonal } from '../middlewares/multer.js'

import { 
    test, 
    homepage, 
    dashboard,
    login_view,
    login_submit,
    competition_view,
    competitionForm_view,
    competitionForm_submit
} from '../controllers/user.controller.js'

import { 
    isValidCompetition 
} from '../validation/user.validation.js'

const routerUser = express.Router()


//GET
routerUser.get('/test', test)
routerUser.get('/', homepage)
routerUser.get('/dashboard', dashboard)
routerUser.get('/login', login_view)
routerUser.get('/competition/:competitionId', isValidCompetition, competition_view)
routerUser.get('/competition/:competitionId/register', competitionForm_view)

//POST
routerUser.post('/login', login_submit)
routerUser.post('/competition/:competitionId/register', isValidCompetition, uploadPersonal, competitionForm_submit)

export { routerUser }