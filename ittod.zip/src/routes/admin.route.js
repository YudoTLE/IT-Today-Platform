import express from 'express'

import { 
    dashboard_view,
    dashboard_addCompetition,
    dashboard_addEvent,
    event_view,
    eventDetail_updateEvent,
    event_updateStatusEvent,
    event_deleteEvent,
    eventDetail_view,
    competition_view,
    competition_deleteCompetition,
    competition_updateStatusCompetition,
    competitionDetail_view, 
    competitionDetail_updateCompetition,
    team_view
} from '../controllers/admin.controller.js'

const routerAdmin = express.Router()

//GET
routerAdmin.get('/dashboard', dashboard_view)
routerAdmin.get('/event', event_view)
routerAdmin.get('/event/:eventId', eventDetail_view)
routerAdmin.get('/competition', competition_view)
routerAdmin.get('/competition/:competitionId', competitionDetail_view)

//POST
routerAdmin.post('/event/add', dashboard_addEvent)
routerAdmin.post('/event/delete/:eventId', event_deleteEvent)
routerAdmin.post('/event/update/:eventId', eventDetail_updateEvent)
routerAdmin.post('/event/updateStatus/:eventId/:statusAvailibility', event_updateStatusEvent)
routerAdmin.post('/competition/add', dashboard_addCompetition)
routerAdmin.post('/competition/update/:competitionId', competitionDetail_updateCompetition)
routerAdmin.post('/competition/delete/:competitionId', competition_deleteCompetition)
routerAdmin.post('/competition/updateStatus/:competitionId/:statusAvailibility', competition_updateStatusCompetition)

//belum di sesuatuin
routerAdmin.get('/dashboard/competition/competition_name/team_name', team_view)

export { routerAdmin }