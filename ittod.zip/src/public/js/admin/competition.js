const form = document.querySelector('tbody')

form.addEventListener('click', (event) => {
    const targeted = event.target.closest('.action.red.hover-brightness-95')
    if(targeted) {
        Swal.fire({
            title: "Are You Sure?",
            text: "You Won't Be Able To Revert This!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Delete Competition"
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                  title: "Deleted!",
                  text: "Competition Has Been Deleted.",
                  icon: "success"
                }).then(() => {
                    targeted.parentElement.submit()
                })
            }
        })
    }
})

form.addEventListener('change', (event) => {
    const targeted = event.target
    if(targeted.type === 'checkbox') {
        if(targeted) targeted.parentElement.submit()
    }
})