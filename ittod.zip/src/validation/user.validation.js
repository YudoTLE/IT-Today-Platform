import { get404 } from '../controllers/error.controller.js'

//import { param, validationResult } from 'express-validator'
//express validator udh ada tapi blm dipake

import { 
    getCompetitionById
} from '../services/user.service.js'

export const isValidCompetition = async (req, res, next) => {
    const { competitionId } = req.params
    console.log(competitionId)
    const valid = await getCompetitionById(competitionId)
    if (valid) return next() 
    else get404(req, res)
}