import { format, fromUnixTime } from 'date-fns'

export const rawMilisecondsToDate = (miliseconds) => {
    return format(fromUnixTime(miliseconds / 1000), 'yyyy-MM-dd')
}