import express from 'express'
import favicon from "serve-favicon"
import expressLayouts from 'express-ejs-layouts'
import cors from 'cors'
import 'dotenv/config'
import * as path from 'path'

import { appPort } from './config/credentials.config.js'
import { routerUser } from './routes/user.route.js'
import { routerAdmin } from './routes/admin.route.js'
import { get404 } from './controllers/error.controller.js'

const app = express()
app.use(express.urlencoded( { extended : true } ))

app.set('view engine', 'ejs'); //menggunakan EJS
app.set('views', path.resolve('./src/views')); //mengarahkan folder views ke folder "src/views"
app.use(cors()); //perizinan policy untuk fetch
app.use(favicon(path.resolve('./src/public/images/browser/logo-ittoday2024.ico'))) //icon untuk tab browser
app.use(express.static(path.resolve('./src/public'))) //agar dapat mengakses image dan css di folder "public"
app.use(expressLayouts); //menggunakan express-ejs-layouts
app.use(express.urlencoded({ extended: true })) //agar dapat membaca data dari form

app.use('/admin', routerAdmin) //utamakan route admin karena takutnya ketiban sama route user

app.use('/', routerUser)

app.use(get404) // 404 Not Found Handler

app.listen(appPort, () => {
    console.log(`App is listening on port ${appPort}`)
})