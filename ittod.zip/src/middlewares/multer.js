import multer from 'multer';
import path from 'path';
import { nanoid } from 'nanoid';

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.resolve('./src/public/images/participants'))
  },
  filename: (req, file, cb) => {
    const { competitionId } = req.params
    const fileName = competitionId + '-' + nanoid() + path.extname(file.originalname)
    cb(null, fileName);
  }
})

const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 1024 * 1024 
    }
})

const uploadPersonal = upload.fields([
  { name: 'leader_student_id_card', maxCount: 1 },
  { name: 'leader_letter_of_active_student_status', maxCount: 1 },
  { name: 'member1_student_id_card', maxCount: 1 },
  { name: 'member1_letter_of_active_student_status', maxCount: 1 },
  { name: 'member2_student_id_card', maxCount: 1 },
  { name: 'member2_letter_of_active_student_status', maxCount: 1 }
])

export { uploadPersonal }