import 'dotenv/config'
import net from 'net'
import { Client } from 'ssh2'

import { sshConfig, dbConfig, proxyPort } from './src/config/credentials.config.js'

let ready = false

// Create an SSH tunnel
let tunnel

const proxy = net.createServer( (sock) => {
  	if (!ready) return sock.destroy()
  		tunnel.forwardOut(
    	sock.remoteAddress,
    	sock.remotePort,
    	dbConfig.host,
    	dbConfig.port,
    	(err, stream) => {
      	if (err) return sock.destroy()
      	sock.pipe(stream)
    	stream.pipe(sock)
    }
  )
})

proxy.listen(proxyPort, dbConfig.host, () => {
  	console.log(`SOCKS proxy server listening on localhost:${proxyPort}`)
})

tunnel = new Client(sshConfig);

tunnel.on("error", (err) => {
  	console.error("SSH connection error:", err)
});

tunnel.on("timeout", () => {
  	console.error("SSH connection timeout")
});

tunnel.on("connect", () => {
  	console.log("SSH Tunnel :: connected")
});

tunnel.on("ready", async () => {
    ready = true
  	console.log("SSH Tunnel :: ready")

	console.log("Going To Main Apps")
	
    await import ('./src/main.js') //Main Code
})

tunnel.connect(sshConfig)