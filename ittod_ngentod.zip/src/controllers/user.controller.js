import { nanoid } from 'nanoid'

import { 
    addTemporaryUser,
    deleteSameTemporaryUser,
    getTemporaryUser,
    addUser,
    addResetPassword,
    getUserByToken,
    resetPasswordUser,
    deleteResetPasswordSameEmail,
    addTeam,
    getPublishedCompetitions
} from '../services/user.service.js'

import { sendEmailVerification, sendResetPasswordVerification } from '../middlewares/nodemailer.middleware.js'

export const homepage = async (req, res) => {
    console.log(req.user)
    return (
        res.render("pages/client/main", {
            title: "IT Today",
            layout: "components/client/layout",
            nav_id: 0
        })
    )
}

export const dashboard = (req, res) => {
    return (
        res.render("pages/client/dashboard", {
            title: "Dashboard",
            layout: "components/client/layout",
            nav_id: 1
        })
    )
}

export const dashboard_competition = (req, res) => {
    return (
        res.render("pages/client/dashboardCompetition", {
            title: "Competition",
            layout: "components/client/layout",
            nav_id: 1
        })
    )
}

export const dashboard_event = (req, res) => {
    return (
        res.render("pages/client/dashboardEvent", {
            title: "Event",
            layout: "components/client/layout",
            nav_id: 1
        })
    )
}

export const dashboard_competitionDetail = (req, res) => {
    return (
        res.render("pages/client/dashboardCompetitionDetail", {
            title: "Competition",
            layout: "components/client/layout",
            nav_id: 1
        })
    )
}

export const dashboard_eventDetail = (req, res) => {
    return (
        res.render("pages/client/dashboardEventDetail", {
            title: "Event",
            layout: "components/client/layout",
            nav_id: 1
        })
    )
}

export const login_view = (req, res) => {
    return (
        res.render("pages/client/login", {
            title: "Login",
            layout: "components/client/layout",
            nav_id: -1,
            specificScript: 'login.js',
            specificCSS: 'login_register.css'
        })
    )
}

export const register_view = (req, res) => {
    return (
        res.render("pages/client/register", {
            title: "Register",
            layout: "components/client/layout",
            nav_id: -1,
            specificScript: 'register.js',
            specificCSS: 'login_register.css'
        })
    )
}

export const register_submit = async (req, res) => {
    const { email, password } = req.body
    const token = nanoid()
    await sendEmailVerification(email, token)
    await addTemporaryUser(email, password, token)
    return res.status(200).json({
        data: 
        {
            status: 'Success',
            message: 'Please verify your email! <br> We have sent a verification link to your email address',
            icon: 'success'
        }
    })
}

export const competition_view = (req, res) => {
    const { competitionId } = req.params
    return res.send(`Competition ${competitionId}`)
}

export const competitionForm_view = (req, res) => {
    const { competitionId } = req.params
    return (
        res.render(`pages/client/registerCompetition`, {
            title: `Register Competition ${competitionId}`,
            layout: "components/client/layout",
            nav_id: 1,
            competitionData: competitionId,
            emailData: req.user
        })
    )
}

export const competitionForm_submit = async (req, res) => {
    const { competitionId } = req.params
    const team_email = req.user.id
    const data = req.body
    const uploadFile = req.files

    await addTeam(competitionId, team_email, data, uploadFile)
    res.redirect('/dashboard')
}

export const verificationEmail_success = async (req, res) => {
    const { token } = req.params
    const { email, password } = await getTemporaryUser(token)

    await addUser(email, password)
    await deleteSameTemporaryUser(email)
    return res.redirect('/login')
}

export const login_resetPassword = async (req, res) => {
    const { email } = req.body
    const token = nanoid()
    await sendResetPasswordVerification(email, token)
    await addResetPassword(email, token)
    return res.status(200).json({ 
        data:
        {
            status: 'Success',
            message: 'We have sent a password reset link to your email address',
            icon: 'success'
        }
    })
}

export const verificationResetPassword_view = (req, res) => {
    const { token } = req.params
    return (
        res.render("pages/client/resetPassword", {
            title: "Reset Password",
            layout: "components/client/layout",
            nav_id: 1,
            data: token
        })
    )
}

export const verificationResetPassword_submit = async (req, res) => {
    const { token } = req.params
    const { email } = await getUserByToken(token)
    const { new_password } = req.body

    await resetPasswordUser(email, new_password)
    await deleteResetPasswordSameEmail(email)
    res.redirect('/login')
}

export const publishedCompetitions = async (req, res) => {
    const datas = await getPublishedCompetitions()
    return res.json(datas)
}