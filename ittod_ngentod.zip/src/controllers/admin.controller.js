import { 
    getEvents,
    getEventById,
    addEvent,
    updateEvent,
    updateStatusEvent,
    deleteEvent,
    getCompetitions,
    getCompetitionById,
    addCompetition,
    deleteCompetition,
    updateCompetition,
    updateStatusCompetition,
    getTeams,
    getTeamById
} from '../services/admin.service.js'
 
export const dashboard_view = async (req, res) => {
    return (
        res.render("pages/admin/main", {
            title: "Dashboard Admin",
            layout: "components/admin/layout",
            competitionDatas: await getCompetitions(),
            eventDatas: await getEvents(),
            specificScript: 'dashboard.js'
        })
    )
}

export const dashboard_addEvent = async (req, res) => {
    await addEvent(req.body)
    return res.redirect('/admin/dashboard')
}

export const dashboard_addCompetition = async (req, res) => {
    console.log(req.file)
    const { filename } = req.file
    const icon = filename

    await addCompetition(req.body, icon)
    return res.redirect('/admin/dashboard')
}

export const event_view = async (req, res) => {
    return (
        res.render("pages/admin/event", {
            title: "Event",
            layout: "components/admin/layout",
            datas: await getEvents(),
            specificScript: 'event.js'
        })
    )
}

export const event_updateStatusEvent = async (req, res) => {
    const { eventId, statusAvailibility } = req.params
    await updateStatusEvent(eventId, statusAvailibility)

    return res.redirect('/admin/event')
}

export const event_deleteEvent = async (req, res) => {
    const { eventId } = req.params
    await deleteEvent(eventId)
    return res.redirect('/admin/event')
}

export const eventDetail_view = async (req, res) => {
    const { eventId } = req.params
    
    return (
        res.render("pages/admin/eventDetail", {
            title: eventId,
            layout: "components/admin/layout",
            eventData: await getEventById(eventId)
        })

    )
}

export const eventDetail_updateEvent = async (req, res) => {
    const { eventId } = req.params
    const submittedForm = req.body
    await updateEvent(eventId, submittedForm)
    return res.redirect(`/admin/event/${eventId}`)
}

export const competition_view = async (req, res) => {
    return (
        res.render("pages/admin/competition", {
            title: "Competition",
            layout: "components/admin/layout",
            datas: await getCompetitions(),
            specificScript: 'competition.js'
        })
    )
}

export const competitionDetail_view = async (req, res) => {
    const { competitionId } = req.params
    
    return (
        res.render("pages/admin/competitionDetail", {
            title: competitionId,
            layout: "components/admin/layout",
            competitionData: await getCompetitionById(competitionId),
            teamDatas: await getTeams(competitionId)
        })

    )
}

export const competition_deleteCompetition = async (req, res) => {
    const { competitionId } = req.params
    await deleteCompetition(competitionId)
    return res.redirect('/admin/competition')
}

export const competition_updateStatusCompetition = async (req, res) => {
    const { competitionId, statusAvailibility } = req.params
    await updateStatusCompetition(competitionId, statusAvailibility)

    return res.redirect('/admin/competition')
}

export const competitionDetail_updateCompetition = async (req, res) => {
    const { competitionId } = req.params
    const submittedForm = req.body
    await updateCompetition(competitionId, submittedForm)
    return res.redirect(`/admin/competition/${competitionId}`)
}

//belum disesuatuin

export const team_view = async (req, res) => {4
    const { competitionId, teamId } = req.params

    return (
        res.render("pages/admin/competitionTeamDetail", {
            title: "team-name",
            layout: "components/admin/layout",
            data: await getTeamById(teamId),
            competitionData: await getCompetitionById(competitionId)
       })
    )
}