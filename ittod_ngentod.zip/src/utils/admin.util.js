import { format, fromUnixTime, getTime } from 'date-fns'

export const dateToMiliseconds = (date) => {
    return getTime(date)
}

export const milisecondsToDate = (miliseconds) => {
    return format(fromUnixTime(miliseconds / 1000), 'dd MMMM yyyy')
}

export const formatId = (name) => {
    return name.replace(/[^a-zA-Z0-9\s]/g, '').split(' ').join('_').toLowerCase()
}

export const rawMilisecondsToDate = (miliseconds) => {
    return format(fromUnixTime(miliseconds / 1000), 'yyyy-MM-dd')
}