import passport from "passport";

export const login_submit = (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            return res.status(500).json({ 
                data: 
                {
                    status: 'Error',
                    message: 'An error occurred during authentication.',
                    icon: 'error'
                }
            })
        }

        if (!user) {
            return res.status(404).json({ 
                data: 
                {
                    status: 'Error',
                    message: info.message,
                    icon: 'error'
                }
            })
        }

        req.logIn(user, (err) => {
            if (err) {
                return res.status(500).json({ 
                    data: 
                    {
                        status: 'Error',
                        message: 'An error occurred during authentication',
                        icon: 'error'
                    }
                })
            }

            return res.status(300).json({ 
                data: 
                    {
                        status: 'Success',
                        message: 'Logged in successfully',
                        icon: 'success'
                    }
                })
        })
    })(req, res, next)
}

export const isGuest = (req, res, next) => {
    if (!req.isAuthenticated()) return next()
    else return res.redirect('/dashboard')
}

export const isLogin = (req, res, next) => {
    if (req.isAuthenticated()) return next()
    else return res.redirect('/login')
}