import express from 'express'

import { uploadIcon } from '../middlewares/multer.middleware.js'

import { 
    dashboard_view,
    dashboard_addCompetition,
    dashboard_addEvent,
    event_view,
    eventDetail_updateEvent,
    event_updateStatusEvent,
    event_deleteEvent,
    eventDetail_view,
    competition_view,
    competition_deleteCompetition,
    competition_updateStatusCompetition,
    competitionDetail_view, 
    competitionDetail_updateCompetition,
    team_view
} from '../controllers/admin.controller.js'

import {
    isValidTeam
} from '../validation/admin.validation.js'

const routerAdmin = express.Router()

//GET
routerAdmin.get('/dashboard', dashboard_view)
routerAdmin.get('/event', event_view)
routerAdmin.get('/event/:eventId', eventDetail_view)
routerAdmin.get('/competition', competition_view)
routerAdmin.get('/competition/:competitionId', competitionDetail_view)
routerAdmin.get('/dashboard/competition/:competitionId/:teamId', isValidTeam, team_view)

//POST
routerAdmin.post('/event/add', dashboard_addEvent)
routerAdmin.post('/event/delete/:eventId', event_deleteEvent)
routerAdmin.post('/event/update/:eventId', eventDetail_updateEvent)
routerAdmin.post('/event/updateStatus/:eventId/:statusAvailibility', event_updateStatusEvent)
routerAdmin.post('/competition/add', uploadIcon, dashboard_addCompetition)
routerAdmin.post('/competition/update/:competitionId', competitionDetail_updateCompetition)
routerAdmin.post('/competition/delete/:competitionId', competition_deleteCompetition)
routerAdmin.post('/competition/updateStatus/:competitionId/:statusAvailibility', competition_updateStatusCompetition)

export { routerAdmin }