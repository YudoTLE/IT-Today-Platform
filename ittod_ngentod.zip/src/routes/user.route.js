import express from 'express'

import { uploadPersonal } from '../middlewares/multer.middleware.js'

import { 
    homepage, 
    dashboard,
    dashboard_competition,
    dashboard_event,
    dashboard_competitionDetail,
    dashboard_eventDetail,
    register_view,
    register_submit,
    login_view,
    competition_view,
    competitionForm_view,
    competitionForm_submit,
    verificationEmail_success,
    login_resetPassword,
    verificationResetPassword_view,
    verificationResetPassword_submit,
    publishedCompetitions
} from '../controllers/user.controller.js'

import { 
    isValidCompetition,
    isValidFirstRegister,
    isValidTemporaryUser,
    isValidUser,
    isValidResetPassword
} from '../validation/user.validation.js'

import { 
    login_submit,
    isGuest,
    isLogin
} from '../auth/user.auth.js'

const routerUser = express.Router()

//GET
routerUser.get('/', homepage)
routerUser.get('/dashboard/competition', isLogin, dashboard_competition)
routerUser.get('/dashboard/event', isLogin, dashboard_event)
routerUser.get('/dashboard/competition/name', isLogin, dashboard_competitionDetail)
routerUser.get('/dashboard/event/name', isLogin, dashboard_eventDetail)
routerUser.get('/dashboard/publishedCompetitions', publishedCompetitions)
routerUser.get('/dashboard', isLogin, dashboard)
routerUser.get('/register', isGuest, register_view)
routerUser.get('/login', isGuest, login_view)
routerUser.get('/competition/:competitionId', isValidCompetition, competition_view)
routerUser.get('/competition/:competitionId/register', isLogin, competitionForm_view)
routerUser.get('/verification/email/:token', isGuest, isValidTemporaryUser, verificationEmail_success)
routerUser.get('/verification/reset_password/:token', isGuest, isValidResetPassword, verificationResetPassword_view)

//POST
routerUser.post('/login', isGuest, login_submit)
routerUser.post('/register', isGuest, isValidFirstRegister, register_submit)
routerUser.post('/competition/:competitionId/register', isLogin, isValidCompetition, uploadPersonal, competitionForm_submit)
routerUser.post('/verification/reset_password', isGuest, isValidUser, login_resetPassword)
routerUser.post('/verification/reset_password/:token', isGuest, verificationResetPassword_submit)

export { routerUser }