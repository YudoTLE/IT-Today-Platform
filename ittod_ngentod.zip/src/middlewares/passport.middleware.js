import { Strategy } from 'passport-local'
import passport from 'passport'

import { getUserByEmail, authenticateUser } from '../services/user.service.js'

//session yg dipanggil saat pertama kali login
passport.serializeUser((id, done) => {
    done(null, id) 
})

//session yg dipanggil setelahnya
passport.deserializeUser( async(id, done) => { 
    const user = await getUserByEmail(id)
    return done(null, user)
})

const localStrategy = new Strategy(
    { usernameField: 'email'}, //karena pada post form field, name = 'email'
    
    async(email, password, done) => {
        const valid = await authenticateUser(email, password)
        if (valid) done(null, email)
        else done(null, false, { message: "Invalid Credentials" })
    }
)

export { localStrategy }