import multer from 'multer'
import path from 'path'
import { nanoid } from 'nanoid'

import { formatId } from '../utils/admin.util.js'

const storageParticipants = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.resolve('./src/public/images/participants'))
  },
  filename: (req, file, cb) => {
    const { competitionId } = req.params
    const fileName = competitionId + '-' + nanoid() + path.extname(file.originalname)
    cb(null, fileName)
  }
})

const storageIcons = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.resolve('./src/public/images/icons'))
  },
  filename: (req, file, cb) => {
    const { name } = req.body
    const id = formatId(name)
    const fileName = id + path.extname(file.originalname)
    cb(null, fileName)
  }
})

const uploadStorage = (storage) => {
  const upload = multer({ 
      storage: storage,
      limits: {
          fileSize: 1024 * 1024 // 1 MB
      },
      fileFilter: (req, file, cb) => {
          const filetypes = /jpeg|jpg|png/  // Only accept jpeg, jpg, and png
          const mimetype = filetypes.test(file.mimetype)
          const extname = filetypes.test(path.extname(file.originalname).toLowerCase())

          if (mimetype && extname) {
              return cb(null, true)
          }

          cb(new Error('Only png, jpg, and jpeg are allowed!'))
      }
  })

  return upload
}

const uploadPersonal = uploadStorage(storageParticipants).fields([
  { name: 'leader_student_id_card', maxCount: 1 },
  { name: 'leader_letter_of_active_student_status', maxCount: 1 },
  { name: 'member1_student_id_card', maxCount: 1 },
  { name: 'member1_letter_of_active_student_status', maxCount: 1 },
  { name: 'member2_student_id_card', maxCount: 1 },
  { name: 'member2_letter_of_active_student_status', maxCount: 1 }
])

const uploadIcon = uploadStorage(storageIcons).single('icon')

export { uploadPersonal, uploadIcon }