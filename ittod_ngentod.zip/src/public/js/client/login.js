resetPassword.addEventListener('click', async (e) => {
    e.preventDefault()
    const { value: email } = await Swal.fire({
        title: "Reset Password",
        input: "email",
        inputLabel: "Your Email Address",
        inputPlaceholder: "Enter Your Email Address"
    });
    if (email) {
        Swal.fire({
            title: 'Please Wait',
            didOpen: () => {
                Swal.showLoading()
            },
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false
        });

        const response = await fetch('/verification/reset_password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email }),
        })

        const { data } = await response.json()
        const { status, message, icon } = data

        Swal.close()

        Swal.fire(status, message, icon)
    }
})

login.addEventListener('submit', async (e) => {
    e.preventDefault()

    const email = document.getElementById('email').value
    const password = document.getElementById('password').value

    Swal.fire({
        title: 'Please Wait',
        didOpen: () => {
            Swal.showLoading()
        },
        allowOutsideClick: false,
        allowEscapeKey: false,
        showConfirmButton: false
    })

    const response = await fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
    })

    const { data } = await response.json()
    const { status, message, icon } = data

    Swal.close()

    Swal.fire(status, message, icon).then((result) => {
        console.log(status)
        if (result.isConfirmed && status === 'Success') window.location.href = '/dashboard'
    })
})