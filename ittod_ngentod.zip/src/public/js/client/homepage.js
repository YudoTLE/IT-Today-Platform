async function fetchData() {
    const responseCompetitions = await fetch('/dashboard/publishedCompetitions')
    let dataCompetitions = await responseCompetitions.json()
    
    dataCompetitions = dataCompetitions.map(dataCompetition => {
        const { name, description, id, icon } = dataCompetition
        return {
            title: name,
            desc: description,
            img_src: `/images/icons/${icon}`,
            hyperlink: `/competition/${id}`
        }
    })

    console.log(dataCompetitions)

    // sisanya fetch2 ke event 
    // const response2 = await fetch('/data2')
    // const data2 = await response2.json()
    // const response3 = await fetch('/data3')
    // const data3 = await response3.json()
    // const response4 = await fetch('/data4')
    // const data4 = await response4.json()

    //const details = [data1, data2, data3, data4];
    const details = [dataCompetitions]

    const titles = document.querySelectorAll('.subcontent h3')
    const descs = document.querySelectorAll('.subcontent p')
    const imgs = document.querySelectorAll('.subcontent img')
    const navPrevs = document.querySelectorAll('.subcontent .nav-prev')
    const navNexts = document.querySelectorAll('.subcontent .nav-next')
    const links = document.querySelectorAll('.subcontent a')
    const n = titles.length
    const item_ids = Array(n).fill(0)

    console.log(n)
    console.log(links.length)

    const updateDetail = (id, item_id) => {
        titles[id].textContent = details[id][item_id].title
        descs[id].textContent = details[id][item_id].desc
        imgs[id].src = details[id][item_id].img_src
        links[id].href = details[id][item_id].hyperlink
    }

    for (let i = 0; i < n; i++) {
        updateDetail(i, item_ids[i])

        navPrevs[i].addEventListener('click', (event) => {
            item_ids[i] = (item_ids[i] + details[i].length - 1) % details[i].length
            updateDetail(i, item_ids[i])
        })
        navNexts[i].addEventListener('click', (event) => {
            item_ids[i] = (item_ids[i] + 1) % details[i].length
            updateDetail(i, item_ids[i])
        })
    }
}

fetchData();