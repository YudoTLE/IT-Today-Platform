addNewCompetition.addEventListener('click', () => {
    formNewCompetition.showModal()
})

addNewEvent.addEventListener('click', () => {
    formNewEvent.showModal()
})

//close if clicked outside the form
formNewCompetition.addEventListener("click", (event) => {
    const formDimensions = formNewCompetition.getBoundingClientRect()
    if (
        event.clientX < formDimensions.left ||
        event.clientX > formDimensions.right ||
        event.clientY < formDimensions.top ||
        event.clientY > formDimensions.bottom
    ) {
        formNewCompetition.close()
    }
})

//event form
formNewEvent.addEventListener("click", (event) => {
    const formDimensions = formNewEvent.getBoundingClientRect()
    if (
        event.clientX < formDimensions.left ||
        event.clientX > formDimensions.right ||
        event.clientY < formDimensions.top ||
        event.clientY > formDimensions.bottom
    ) {
        formNewEvent.close()
    }
})