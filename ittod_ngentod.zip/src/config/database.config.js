import pg from 'pg'
import { dbConfig, proxyPort } from './credentials.config.js'

const { Pool } = pg

const connectString = `postgres://${dbConfig.user}:${dbConfig.password}@${dbConfig.host}:${proxyPort}/${dbConfig.database}`

const pool = new Pool({
	connectionString: connectString,
	max: 10, // pool Size
	idleTimeoutMillis: 30000, // Timeout After 30 seconds
})

const db = (text, params) => pool.query(text, params)

export { db, connectString }