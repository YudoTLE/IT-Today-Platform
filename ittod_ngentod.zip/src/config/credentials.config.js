import 'dotenv/config'

// SSH configuration
const sshConfig = {
	host: process.env.SSH_HOST,
	port: process.env.SSH_PORT,
	username: process.env.SSH_USERNAME,
	password: process.env.SSH_PASSWORD
};

// Database configuration
const dbConfig = {
  	host: process.env.DB_HOST,
  	port: process.env.DB_PORT, 
  	user: process.env.DB_USER,
  	password: process.env.DB_PASSWORD,
  	database: process.env.DB_NAME,
}

// Other Port Configuration
const proxyPort = process.env.PROXY_PORT
const appPort = process.env.PORT

export { sshConfig, dbConfig, proxyPort, appPort }