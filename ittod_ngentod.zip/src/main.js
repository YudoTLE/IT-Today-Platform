import express from 'express'
import favicon from "serve-favicon"
import expressLayouts from 'express-ejs-layouts'
import cors from 'cors'
import 'dotenv/config'
import * as path from 'path'
import session from 'express-session'
import passport from 'passport'
import flash from 'express-flash'
import pgSession from 'connect-pg-simple'

import { appPort } from './config/credentials.config.js'
import { routerUser } from './routes/user.route.js'
import { routerAdmin } from './routes/admin.route.js'
import { get404 } from './controllers/error.controller.js'
import { localStrategy as passportLocal } from './middlewares/passport.middleware.js'
import { connectString } from './config/database.config.js'

const app = express()

app.use(express.json())
app.set('view engine', 'ejs') //menggunakan EJS
app.set('views', path.resolve('./src/views')) //mengarahkan folder views ke folder "src/views"
app.use(cors()) //perizinan policy untuk fetch
app.use(favicon(path.resolve('./src/public/images/browser/logo-ittoday2024.ico'))) //icon untuk tab browser
app.use(express.static(path.resolve('./src/public'))) //agar dapat mengakses image dan css di folder "public"
app.use(expressLayouts) //menggunakan express-ejs-layouts
app.use(express.urlencoded({ extended: true })) //agar dapat membaca data dari form

app.use(session({
    //agar session disimpan di database ketika down (tidak perlu login ulang)
    store: new (pgSession(session))({
        conString: connectString
    }), 
    secret: process.env.SECRET, //kode encrypt session (kalau bisa panjang)
    saveUninitialized: false, //kalau ga login, ga usah disimpen
    resave: false, //kalau ga ada perubahan, ga usah diupdate 
    cookie: {
        maxAge: 60 * 60 * 1000 //1 jam
    }
}))

app.use(passport.initialize())
app.use(passport.session())
passport.use(passportLocal)
app.use(flash()) //flash message

app.use('/admin', routerAdmin) //utamakan route admin karena takutnya ketiban sama route user

app.use('/', routerUser)

app.use(get404) // 404 Not Found Handler

app.listen(appPort, () => {
    console.log(`App is listening on port ${appPort}`)
})