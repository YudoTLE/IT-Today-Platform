import { get404 } from '../controllers/error.controller.js'

import { getTeamById } from '../services/admin.service.js'

export const isValidTeam = async (req, res, next) => {
    const { teamId } = req.params
    const valid = await getTeamById(teamId)

    if (valid) return next()
    else get404(req, res)
}