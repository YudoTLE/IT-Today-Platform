import { get404 } from '../controllers/error.controller.js'

//import { param, validationResult } from 'express-validator'
//express validator udh ada tapi blm dipake

import { 
    getCompetitionById,
    getTemporaryUser,
    deleteExpiredTemporaryUser,
    getUserByEmail,
    deleteExpiredResetPassword,
    getResetPassword
} from '../services/user.service.js'

export const isValidCompetition = async (req, res, next) => {
    const { competitionId } = req.params
    const valid = await getCompetitionById(competitionId)
   
    if (valid) return next() 
    else get404(req, res)
}

export const isValidTemporaryUser = async (req, res, next) => {
    const { token } = req.params
    await deleteExpiredTemporaryUser()
    const valid = await getTemporaryUser(token)
 
    if (valid) return next()
    else get404(req, res)
}

export const isValidUser = async (req, res, next) => {
    const { email } = req.body
    const valid = await getUserByEmail(email)

    if (valid) return next()
    else return res.status(404).json({ 
        data: {
            status: 'Error',
            message: 'User not found',
            icon: 'error'
        }
    })
}

export const isValidFirstRegister = async (req, res, next) => {
    const { email } = req.body
    const isRegistered = await getUserByEmail(email)
    const valid = !isRegistered

    if (valid) return next()
    else return res.status(404).json({
        data: 
        {
            status: 'Error',
            message: 'Email has been registered',
            icon: 'error'
        }
    })
}

export const isValidResetPassword = async (req, res, next) => {
    const { token } = req.params
    await deleteExpiredResetPassword()

    const valid = await getResetPassword(token)
    if (valid) return next()
    else get404(req, res)
}