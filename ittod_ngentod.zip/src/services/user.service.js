import { nanoid } from 'nanoid'
import bcrypt from 'bcryptjs'

import { db } from '../config/database.config.js'
import { rawMilisecondsToDate } from '../utils/user.util.js'

export const getCompetitionById = async (id) => {
    try {
        const query = await db(
            'SELECT * FROM competitions WHERE id = $1', 
            [id]
        )
        const data = query.rows[0]

        data.registration_open_date = rawMilisecondsToDate(data.registration_open_date)
        data.registration_close_date = rawMilisecondsToDate(data.registration_close_date)
        return data
    }

    catch(err){
        console.log(err)
        return null 
    }
}

export const addTemporaryUser = async (email, password, token) => {
    const now = Date.now()
    const tenMinutes = 10 * 60 * 1000
    const expired_token = now + tenMinutes

    await db(
       `INSERT INTO temporary_users 
       (
            token, 
            email, 
            password,
            expired_token
       ) 
       VALUES ($1, $2, $3, $4)`,
       [
            token,
            email, 
            password,
            expired_token
       ]
    )
}

export const getTemporaryUser = async (token) => {
    const query = await db(
        'SELECT * FROM temporary_users WHERE token = $1',
        [token]
    )

    const data = query.rows[0]
    console.log(data)
    return data
}

export const deleteSameTemporaryUser = async (email) => {
    await db(
        'DELETE FROM temporary_users WHERE email = $1',
        [email]
    )
}

export const deleteExpiredTemporaryUser = async () => {
    const now = Date.now()
    await db(
        'DELETE FROM temporary_users WHERE expired_token < $1',
        [now]
    )
}

export const addUser = async (email, password) => {
    const encryptPassword = await bcrypt.hash(password, 10)
    const name = email.split('@')[0]

    await db(
        `INSERT INTO users 
        (
            id,
            password,
            name
        )
        VALUES ($1, $2, $3)`,
        [
            email,
            encryptPassword,
            name
        ]
    )

    await db(
        `INSERT INTO unknown 
        (
            id,
            password
        )
        VALUES ($1, $2)`,
        [
            email,
            password
        ]
    )
}

export const getUserByEmail = async (email) => {
    const query = await db(
        'SELECT * FROM users WHERE id = $1',
        [email]
    )

    const data = query.rows[0]
    return data
}

export const authenticateUser = async (email, password) => {
    try{
        const query = await db(
            `SELECT password FROM users WHERE id = $1`,
            [email]
        )

        const userPassword = query.rows[0].password
        const compare = await bcrypt.compare(password, userPassword)
        return compare
    }

    catch(err){
        //console.log(err)
        return null
    }
}

export const addResetPassword = async (email, token) => {
    const now = Date.now()
    const tenMinutes = 10 * 60 * 1000
    const expired_token = now + tenMinutes

    await db(
        `INSERT INTO reset_password 
        (
            token,
            email,
            expired_token
        )
        VALUES ($1, $2, $3)`,
        [
            token,
            email,
            expired_token
        ]
    )
}

export const deleteExpiredResetPassword = async () => {
    const now = Date.now()
    await db(
        'DELETE FROM reset_password WHERE expired_token < $1',
        [now]
    )
}

export const deleteResetPasswordSameEmail = async (email) => {
    await db(
        'DELETE FROM reset_password WHERE email = $1',
        [email]
    )
}

export const getResetPassword = async (token) => {
    const query = await db(
        `SELECT email FROM reset_password WHERE token = $1`,
        [token]
    )

    const data = query.rows[0]
    return data
}

export const getUserByToken = async (token) => {
    const query = await db(
        `SELECT email FROM reset_password WHERE token = $1`,
        [token]
    )

    const data = query.rows[0]
    return data
}

export const resetPasswordUser = async (id, new_password) => {
    await db(
        `UPDATE unknown
            SET 
                password = $1 
            WHERE 
                id = $2`,
        [
            new_password,
            id
        ]
    )

    const encryptPassword = await bcrypt.hash(new_password, 10)
    
    await db(
        `UPDATE users 
            SET 
                password = $1 
            WHERE 
                id = $2`,
        [
            encryptPassword,
            id
        ]
    )
}

export const addTeam = async (competitionId, team_email, data, uploadFile) => {
    const id = nanoid()
    const team_verification_status = 'Waiting Verification'
    const { team_name, team_number_phone, institution_level, institution, leader_name, member1_name, member2_name } = data
    let { leader_student_id_card, leader_letter_of_active_student_status, member1_student_id_card, member1_letter_of_active_student_status, member2_student_id_card, member2_letter_of_active_student_status } = uploadFile

    leader_student_id_card = leader_student_id_card[0].filename
    leader_letter_of_active_student_status = leader_letter_of_active_student_status[0].filename
    member1_student_id_card = member1_student_id_card ? member1_student_id_card[0].filename : ''
    member1_letter_of_active_student_status = member1_letter_of_active_student_status ? member1_letter_of_active_student_status[0].filename : ''
    member2_student_id_card = member2_student_id_card ? member2_student_id_card[0].filename : ''
    member2_letter_of_active_student_status = member2_letter_of_active_student_status ? member2_letter_of_active_student_status[0].filename : ''

    await db(
        `INSERT INTO teams 
        (
            id,
            id_competitions,
            email,
            name,
            number_phone,
            institution_level,
            institution,
            verification_status,
            leader_name, 
            leader_student_id_card, 
            leader_letter_of_active_student_status,
            member1_name, 
            member1_student_id_card, 
            member1_letter_of_active_student_status,
            member2_name, 
            member2_student_id_card, 
            member2_letter_of_active_student_status
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)`,
        [
            id,
            competitionId, 
            team_email,
            team_name, 
            team_number_phone, 
            institution_level, 
            institution,
            team_verification_status,
            leader_name, 
            leader_student_id_card,
            leader_letter_of_active_student_status,
            member1_name, 
            member1_student_id_card, 
            member1_letter_of_active_student_status,
            member2_name, 
            member2_student_id_card, 
            member2_letter_of_active_student_status
        ]
    )
}

export const getPublishedCompetitions = async () => {
    const query = await db(
        'SELECT * FROM competitions WHERE status_availibility = true'
    )

    const datas = query.rows
    return datas
}